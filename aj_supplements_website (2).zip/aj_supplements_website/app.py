from flask import Flask, render_template, request

app = Flask(__name__)

@app.route("/", methods=["GET", "POST"])
def index():
    if request.method == "POST":
        print("Form Submission:")
        for key, value in request.form.items():
            print(f"{key}: {value}")
        return render_template("index.html", submitted=True)
    return render_template("index.html", submitted=False)

if __name__ == "__main__":
    app.run(debug=True)
