<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $to = "hguntaka@ajsupplements.com, contact@ajsupplements.com, tmadem@ajsupplements.com, info@ajsupplements.com,aj@ajsupplements.com";
    $subject = "New Inquiry Received - AJ Supplements";

    $name = htmlspecialchars($_POST['name']);
    $email = htmlspecialchars($_POST['email']);
    $phone = htmlspecialchars($_POST['phone']);
    $address = htmlspecialchars($_POST['address']);
    $business = htmlspecialchars($_POST['business']);
    $products = htmlspecialchars($_POST['products']);
    $quantity = htmlspecialchars($_POST['quantity']);
    $packaging = htmlspecialchars($_POST['packaging']);
    $message = htmlspecialchars($_POST['message']);
    $productType = htmlspecialchars($_POST['productType']);

    // Save data to CSV file
    $csvFile = 'inquiries.csv'; 
    $csvData = [
        date('Y-m-d H:i:s'), 
        $name,
        $email,
        $phone,
        $address,
        $business,
        $products,
        $quantity,
        $packaging,
        $productType,
        $message
    ];

    if (!file_exists($csvFile)) {
        $file = fopen($csvFile, 'w');
        fputcsv($file, ['Date', 'Name', 'Email', 'Phone', 'Address', 'Business Type', 'Products', 'Quantity', 'Packaging', 'Selected Product', 'Message']); 
    } else {
        $file = fopen($csvFile, 'a');
    }

    if ($file) {
        fputcsv($file, $csvData);
        fclose($file);
    } else {
        error_log("Failed to write to CSV file: $csvFile");
    }

    // Email to admin team
    $body = "
    <html>
    <head>
        <style>
            table { width: 100%; border-collapse: collapse; }
            th, td { padding: 10px; border: 1px solid #ddd; text-align: left; }
            th { background-color: #f2f2f2; }
        </style>
    </head>
    <body>
        <h2>New Inquiry Received - AJ Supplements</h2>
        <table>
            <tr><th>Name</th><td>{$name}</td></tr>
            <tr><th>Email</th><td>{$email}</td></tr>
            <tr><th>Phone</th><td>{$phone}</td></tr>
            <tr><th>Address</th><td>{$address}</td></tr>
            <tr><th>Business Type</th><td>{$business}</td></tr>
            <tr><th>Products Interested</th><td>{$products}</td></tr>
            <tr><th>Quantity</th><td>{$quantity}</td></tr>
            <tr><th>Packaging</th><td>{$packaging}</td></tr>
            <tr><th>Selected Product</th><td>{$productType}</td></tr>
            <tr><th>Message</th><td>{$message}</td></tr>
        </table>
    </body>
    </html>
    ";

    $headers = "MIME-Version: 1.0" . "\r\n";
    $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
    $headers .= "From: contact@ajsupplements.com\r\n"; 
    $headers .= "Reply-To: $email\r\n";
    $headers .= "X-Mailer: PHP/" . phpversion();

    if (mail($to, $subject, $body, $headers)) {
        
        // Send confirmation email to user
        $userSubject = "Your Inquiry Has Been Submitted - AJ Supplements";
        $userBody = "
        <html>
        <head>
            <style>
                table { width: 100%; border-collapse: collapse; }
                th, td { padding: 10px; border: 1px solid #ddd; text-align: left; }
                th { background-color: #f2f2f2; }
            </style>
        </head>
        <body>
            <h2>Thank you for contacting AJ Supplements</h2>
            <p>We have received your inquiry and will get back to you shortly. Below are the details of your submission:</p>
            <table>
                <tr><th>Name</th><td>{$name}</td></tr>
                <tr><th>Email</th><td>{$email}</td></tr>
                <tr><th>Phone</th><td>{$phone}</td></tr>
                <tr><th>Address</th><td>{$address}</td></tr>
                <tr><th>Business Type</th><td>{$business}</td></tr>
                <tr><th>Products Interested</th><td>{$products}</td></tr>
                <tr><th>Quantity</th><td>{$quantity}</td></tr>
                <tr><th>Packaging</th><td>{$packaging}</td></tr>
                <tr><th>Selected Product</th><td>{$productType}</td></tr>
                <tr><th>Message</th><td>{$message}</td></tr>
            </table>
            <p>Thank you for your inquiry! We look forward to assisting you.</p>
        </body>
        </html>
        ";

        $userHeaders = "MIME-Version: 1.0" . "\r\n";
        $userHeaders .= "Content-type:text/html;charset=UTF-8" . "\r\n";
        $userHeaders .= "From: contact@ajsupplements.com\r\n"; 
        $userHeaders .= "Reply-To: contact@ajsupplements.com\r\n";
        $userHeaders .= "X-Mailer: PHP/" . phpversion();

        if (mail($email, $userSubject, $userBody, $userHeaders)) {
            echo "<script>alert('Inquiry submitted successfully! Thank you.'); window.location.href = '/';</script>";
        } else {
            echo "<script>alert('Sorry, there was an error sending the confirmation email. Please try again later.'); window.history.back();</script>";
        }

    } else {
        echo "<script>alert('Sorry, there was an error sending your inquiry. Please try again later.'); window.history.back();</script>";
    }
}
?>
